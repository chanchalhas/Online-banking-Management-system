# Nova Bank — Online Banking System

A full-stack online banking application that simulates core banking operations: account management, balance checks and fund transfers.

| Layer    | Technology                                          |
|----------|-----------------------------------------------------|
| Frontend | React 18 (JavaScript), Vite, React Router, Axios    |
| Backend  | Java 17, Spring Boot 3, Spring Security (JWT), JDBC |
| Database | MySQL 8, queried with plain SQL (no ORM)            |

## Features

- **Login authentication** — register and log in; every banking page and API call is restricted to the logged-in customer (JWT, BCrypt-hashed passwords)
- **Account management** — a savings account is created at sign-up; open up to 5 savings or current accounts; deposit demo cash
- **Check balance** — total balance and per-account balance on the dashboard, with a hide/show toggle
- **Fund transfers** — pick the source account, enter the beneficiary's account number, see the account holder's name, review, then confirm; a receipt with a reference number is shown
- **Validation to prevent incorrect transactions**
  - amount must be greater than zero, with at most 2 decimal places
  - amount cannot exceed the available balance or the per-transfer limit
  - cannot send to the same account; beneficiary account must exist
  - you can only send from accounts you own
  - checked in the browser for quick feedback **and again on the server**
- **Transaction history** — every deposit and transfer, newest first, filterable by account, with the running balance after each entry
- **SQL for inserting, updating and retrieving records** — all database access is hand-written SQL in `backend/src/main/java/com/bank/repository`

## How a transfer stays safe

A transfer runs inside one database transaction (`TransferService.transfer`):

1. Check the source account belongs to the logged-in user and the destination exists
2. Lock both account rows with `SELECT ... FOR UPDATE` (always in id order, so two opposite transfers cannot deadlock)
3. Re-read the balances and check there is enough money
4. `UPDATE accounts SET balance = balance - ? WHERE id = ? AND balance >= ?` for the sender, then add to the receiver
5. `INSERT` a row into `transactions`

If any step fails, nothing is changed. The table also has `CHECK (balance >= 0)`, so the database itself refuses a negative balance.

## Project structure

```
online-banking-system/
├── database/schema.sql          # MySQL schema (optional - created automatically on start)
├── backend/                     # Spring Boot REST API
│   ├── pom.xml
│   └── src/main/
│       ├── resources/           # application.properties, schema.sql
│       └── java/com/bank/
│           ├── config/          # SecurityConfig, DataSeeder (demo customers)
│           ├── controller/      # Auth, Account, Transfer endpoints
│           ├── service/         # Business rules and validation
│           ├── repository/      # SQL queries (JdbcTemplate)
│           ├── model/           # User, Account, TxnRow
│           ├── dto/             # Request / response objects
│           ├── security/        # JWT service + filter
│           └── exception/       # Error handling
└── frontend/                    # React app
    └── src/
        ├── api/                 # Axios client (adds the JWT automatically)
        ├── context/             # Login state
        ├── components/          # Navbar, ProtectedRoute, TransactionList, Alert
        └── pages/               # Login, Register, Dashboard, Transfer, Transactions
```

## Database tables

| Table          | Purpose                                                              |
|----------------|----------------------------------------------------------------------|
| `users`        | name, email (unique), BCrypt password hash, phone                    |
| `accounts`     | owner, account number (unique), type, balance `DECIMAL(15,2)`        |
| `transactions` | reference, type (DEPOSIT / TRANSFER), from/to account, amount, balance after each side, note, time |

## Prerequisites

- JDK 17 or newer
- Maven 3.8+
- Node.js 18 or newer
- MySQL 8.0.16 or newer running locally

## Setup & run

### 1. Backend (http://localhost:8081)

The backend creates the `online_banking` database and its tables automatically on first start. Set your MySQL login first (defaults are `root` / `root`):

```bash
cd backend

# macOS / Linux
export DB_USERNAME=root
export DB_PASSWORD=your_mysql_password

# Windows (PowerShell)
$env:DB_USERNAME="root"; $env:DB_PASSWORD="your_mysql_password"

mvn spring-boot:run
```

Or edit `backend/src/main/resources/application.properties`.

On the first run it adds two demo customers with some starting balance and history:

| Customer     | Email            | Password     | Accounts                        |
|--------------|------------------|--------------|---------------------------------|
| Aarav Sharma | `demo@bank.com`  | `demo1234`   | Savings `1000000001`, Current `1000000002` |
| Priya Nair   | `friend@bank.com`| `friend1234` | Savings `1000000003`            |

Log in as Aarav and send money to `1000000003` to try a transfer.

### 2. Frontend (http://localhost:5174)

```bash
cd frontend
npm install
npm run dev
```

If your backend is not on `http://localhost:8081`, copy `.env.example` to `.env` and edit `VITE_API_URL`.

## API reference

Base URL `http://localhost:8081/api`. Send `Authorization: Bearer <token>` on every route except register and login.

| Method | Endpoint                          | Description                                   |
|--------|-----------------------------------|-----------------------------------------------|
| POST   | `/auth/register`                  | Create a customer and a savings account       |
| POST   | `/auth/login`                     | Log in, returns `{ token, user }`             |
| GET    | `/auth/me`                        | Current customer                              |
| GET    | `/accounts`                       | My accounts with balances                     |
| POST   | `/accounts`                       | Open another account `{ "type": "SAVINGS" }`  |
| GET    | `/accounts/{id}`                  | One account and its balance                   |
| POST   | `/accounts/{id}/deposit`          | Demo cash deposit `{ "amount": 500 }`         |
| GET    | `/accounts/lookup/{accountNumber}`| Beneficiary name, to confirm before paying    |
| POST   | `/transfers`                      | Transfer money                                |
| GET    | `/transactions?accountId=&limit=` | Transaction history                           |

Example transfer:

```json
{
  "fromAccountId": 1,
  "toAccountNumber": "1000000003",
  "amount": 1500.00,
  "description": "Dinner split"
}
```

## Configuration

Set in `backend/src/main/resources/application.properties`, or override with environment variables:

| Setting                 | Purpose                               | Default                 |
|-------------------------|---------------------------------------|-------------------------|
| `DB_USERNAME` / `DB_PASSWORD` | MySQL login                     | `root` / `root`         |
| `JWT_SECRET`            | JWT signing key (32+ characters)      | a placeholder — change it |
| `CORS_ORIGINS`          | Allowed frontend origins              | `http://localhost:5174` |
| `app.bank.max-transfer` | Largest single transfer               | 100000                  |
| `app.bank.max-deposit`  | Largest single demo deposit           | 50000                   |

## Notes

- This is a learning project. No real money is involved; "Deposit cash" simply adds demo money to an account.
- Before sharing or deploying, change the demo passwords and `JWT_SECRET`.
- To build the frontend for production: `npm run build` (output in `frontend/dist`). To package the backend: `mvn clean package`.

## Troubleshooting

- **`Access denied for user 'root'`** — set `DB_USERNAME` / `DB_PASSWORD` to your MySQL login.
- **"Cannot reach the server"** in the browser — the backend is not running, or `VITE_API_URL` is wrong.
- **CORS error** — add your frontend URL to `CORS_ORIGINS`.
- **Port already in use** — change `server.port` in `application.properties` and update `VITE_API_URL`.
