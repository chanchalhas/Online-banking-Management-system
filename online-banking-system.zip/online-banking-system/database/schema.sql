CREATE DATABASE IF NOT EXISTS online_banking
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE online_banking;

-- Online Banking System - MySQL schema
-- Applied automatically on start. To create it by hand instead:
--   mysql -u root -p < database/schema.sql

CREATE TABLE IF NOT EXISTS users (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password      VARCHAR(255) NOT NULL,
  phone         VARCHAR(20),
  created_at    DATETIME     NOT NULL
);

CREATE TABLE IF NOT EXISTS accounts (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id        BIGINT         NOT NULL,
  account_number VARCHAR(12)    NOT NULL UNIQUE,
  account_type   VARCHAR(20)    NOT NULL,
  balance        DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
  created_at     DATETIME       NOT NULL,
  CONSTRAINT fk_account_user FOREIGN KEY (user_id) REFERENCES users (id),
  -- the database itself refuses a negative balance, even if application code had a bug
  CONSTRAINT chk_balance_not_negative CHECK (balance >= 0),
  INDEX idx_account_user (user_id)
);

CREATE TABLE IF NOT EXISTS transactions (
  id                 BIGINT AUTO_INCREMENT PRIMARY KEY,
  reference          VARCHAR(20)    NOT NULL UNIQUE,
  txn_type           VARCHAR(20)    NOT NULL,          -- DEPOSIT or TRANSFER
  from_account_id    BIGINT         NULL,              -- NULL for a cash deposit
  to_account_id      BIGINT         NULL,
  amount             DECIMAL(15, 2) NOT NULL,
  from_balance_after DECIMAL(15, 2) NULL,
  to_balance_after   DECIMAL(15, 2) NULL,
  description        VARCHAR(140),
  created_at         DATETIME       NOT NULL,
  CONSTRAINT fk_txn_from FOREIGN KEY (from_account_id) REFERENCES accounts (id),
  CONSTRAINT fk_txn_to   FOREIGN KEY (to_account_id)   REFERENCES accounts (id),
  CONSTRAINT chk_amount_positive CHECK (amount > 0),
  INDEX idx_txn_from (from_account_id),
  INDEX idx_txn_to (to_account_id),
  INDEX idx_txn_created (created_at)
);
