import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import api, { session } from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => (session.token() ? session.user() : null));

  const finish = useCallback((data) => {
    session.save(data.token, data.user);
    setUser(data.user);
  }, []);

  const login = useCallback(
    async (email, password) => finish((await api.post('/auth/login', { email, password })).data),
    [finish]
  );

  const register = useCallback(async (form) => finish((await api.post('/auth/register', form)).data), [finish]);

  const logout = useCallback(() => {
    session.clear();
    setUser(null);
  }, []);

  const value = useMemo(() => ({ user, login, register, logout }), [user, login, register, logout]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
