import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function Logo() {
  return (
    <svg width="28" height="28" viewBox="0 0 100 100" aria-hidden="true">
      <rect width="100" height="100" rx="22" fill="var(--navy)" />
      <path d="M50 18 18 36h64zM26 42h10v28H26zm19 0h10v28H45zm19 0h10v28H64zM20 76h60v8H20z" fill="var(--teal)" />
    </svg>
  );
}

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="navbar">
      <div className="container navbar-inner">
        <Link to={user ? '/' : '/login'} className="brand">
          <Logo />
          <span>Nova Bank</span>
        </Link>

        {user && (
          <>
            <nav className="nav-links" aria-label="Main">
              <NavLink to="/" end>Dashboard</NavLink>
              <NavLink to="/transfer">Transfer</NavLink>
              <NavLink to="/transactions">Transactions</NavLink>
            </nav>
            <div className="nav-actions">
              <span className="nav-user">{user.fullName}</span>
              <button className="btn btn-ghost btn-sm" onClick={handleLogout}>Log out</button>
            </div>
          </>
        )}
      </div>
    </header>
  );
}
