import { formatDate, formatMoney, maskAccount } from '../utils';

const SIGN = { CREDIT: '+', DEBIT: '−', INTERNAL: '' };
const LABEL = { CREDIT: 'Credit', DEBIT: 'Debit', INTERNAL: 'Own transfer' };

/** Statement table. Scrolls sideways inside its own box on narrow screens. */
export default function TransactionList({ items, showBalance = true }) {
  if (items.length === 0) {
    return <p className="muted empty">No transactions yet.</p>;
  }

  return (
    <div className="table-wrap">
      <table className="table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Details</th>
            <th>Type</th>
            <th className="num">Amount</th>
            {showBalance && <th className="num">Balance</th>}
          </tr>
        </thead>
        <tbody>
          {items.map((t) => (
            <tr key={t.id}>
              <td className="nowrap">{formatDate(t.createdAt)}</td>
              <td>
                <div className="txn-title">{t.counterpartyName}</div>
                <div className="muted small">
                  {t.description}
                  {t.counterpartyAccount && t.type === 'TRANSFER' ? ` · ${maskAccount(t.counterpartyAccount)}` : ''}
                  {' · '}
                  <span className="mono">{t.reference}</span>
                </div>
              </td>
              <td><span className={`pill pill-${t.direction.toLowerCase()}`}>{LABEL[t.direction]}</span></td>
              <td className={`num amount amount-${t.direction.toLowerCase()}`}>
                {SIGN[t.direction]}{formatMoney(t.amount)}
              </td>
              {showBalance && <td className="num">{t.balanceAfter == null ? '—' : formatMoney(t.balanceAfter)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
