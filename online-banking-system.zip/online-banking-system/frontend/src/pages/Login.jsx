import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errorMessage } from '../api/client';
import Alert from '../components/Alert';

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const expired = new URLSearchParams(location.search).get('expired');

  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await login(form.email, form.password);
      navigate(location.state?.from || '/', { replace: true });
    } catch (err) {
      setError(errorMessage(err, 'Login failed'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container auth-page">
      <div className="auth-intro">
        <h1>Banking that stays out of your way.</h1>
        <p>Check balances, send money and review every transaction in one place.</p>
        <p className="demo-hint">
          Demo login: <code>demo@bank.com</code> / <code>demo1234</code>
        </p>
      </div>

      <form className="card form auth-card" onSubmit={submit}>
        <h2>Log in</h2>
        {expired && <Alert type="info">Your session expired. Please log in again.</Alert>}
        <Alert>{error}</Alert>
        <label htmlFor="email">
          Email
          <input id="email" className="input" type="email" required autoComplete="email"
                 value={form.email} onChange={update('email')} />
        </label>
        <label htmlFor="password">
          Password
          <input id="password" className="input" type="password" required autoComplete="current-password"
                 value={form.password} onChange={update('password')} />
        </label>
        <button className="btn btn-primary btn-block" disabled={submitting}>
          {submitting ? 'Logging in…' : 'Log in'}
        </button>
        <p className="muted center">
          New customer? <Link to="/register">Open an account</Link>
        </p>
      </form>
    </div>
  );
}
