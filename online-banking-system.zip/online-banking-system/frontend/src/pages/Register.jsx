import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errorMessage } from '../api/client';
import Alert from '../components/Alert';

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ fullName: '', email: '', password: '', confirm: '', phone: '' });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.password !== form.confirm) {
      setError('Passwords do not match');
      return;
    }
    setSubmitting(true);
    try {
      const payload = { fullName: form.fullName, email: form.email, password: form.password };
      if (form.phone.trim()) payload.phone = form.phone.trim();
      await register(payload);
      navigate('/', { replace: true });
    } catch (err) {
      setError(errorMessage(err, 'Registration failed'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container auth-page">
      <div className="auth-intro">
        <h1>Open your account in a minute.</h1>
        <p>We create a savings account for you straight away. Add money, send money, track everything.</p>
      </div>

      <form className="card form auth-card" onSubmit={submit}>
        <h2>Open an account</h2>
        <Alert>{error}</Alert>
        <label htmlFor="fullName">
          Full name
          <input id="fullName" className="input" required maxLength={100} autoComplete="name"
                 value={form.fullName} onChange={update('fullName')} />
        </label>
        <label htmlFor="email">
          Email
          <input id="email" className="input" type="email" required autoComplete="email"
                 value={form.email} onChange={update('email')} />
        </label>
        <label htmlFor="phone">
          Phone <span className="muted">(optional)</span>
          <input id="phone" className="input" type="tel" maxLength={20} autoComplete="tel"
                 value={form.phone} onChange={update('phone')} />
        </label>
        <label htmlFor="password">
          Password <span className="muted">(at least 8 characters)</span>
          <input id="password" className="input" type="password" required minLength={8} autoComplete="new-password"
                 value={form.password} onChange={update('password')} />
        </label>
        <label htmlFor="confirm">
          Confirm password
          <input id="confirm" className="input" type="password" required autoComplete="new-password"
                 value={form.confirm} onChange={update('confirm')} />
        </label>
        <button className="btn btn-primary btn-block" disabled={submitting}>
          {submitting ? 'Creating account…' : 'Create account'}
        </button>
        <p className="muted center">
          Already a customer? <Link to="/login">Log in</Link>
        </p>
      </form>
    </div>
  );
}
