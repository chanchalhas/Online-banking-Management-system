import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errorMessage } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { formatMoney, maskAccount } from '../utils';
import Alert from '../components/Alert';
import TransactionList from '../components/TransactionList';

export default function Dashboard() {
  const { user } = useAuth();
  const [accounts, setAccounts] = useState([]);
  const [recent, setRecent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [hidden, setHidden] = useState(false);

  const [depositFor, setDepositFor] = useState(null);
  const [depositAmount, setDepositAmount] = useState('');
  const [newType, setNewType] = useState('SAVINGS');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [acc, txn] = await Promise.all([api.get('/accounts'), api.get('/transactions', { params: { limit: 6 } })]);
      setAccounts(acc.data);
      setRecent(txn.data);
      setError('');
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const total = accounts.reduce((sum, a) => sum + Number(a.balance), 0);
  const money = (v) => (hidden ? '₹ ••••••' : formatMoney(v));

  const deposit = async (e) => {
    e.preventDefault();
    setError('');
    setNotice('');
    const amount = Number(depositAmount);
    if (!(amount > 0)) {
      setError('Enter an amount greater than zero');
      return;
    }
    setBusy(true);
    try {
      await api.post(`/accounts/${depositFor}/deposit`, { amount });
      setNotice(`${formatMoney(amount)} deposited`);
      setDepositFor(null);
      setDepositAmount('');
      await load();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const openAccount = async () => {
    setError('');
    setNotice('');
    setBusy(true);
    try {
      await api.post('/accounts', { type: newType });
      setNotice('New account opened');
      await load();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <div className="container page"><p className="muted">Loading your accounts…</p></div>;

  return (
    <div className="container page">
      <div className="page-head">
        <div>
          <p className="eyebrow">Welcome back</p>
          <h1>{user.fullName}</h1>
        </div>
        <Link to="/transfer" className="btn btn-primary">Send money</Link>
      </div>

      <Alert>{error}</Alert>
      <Alert type="success">{notice}</Alert>

      <section className="card total-card">
        <div>
          <p className="eyebrow light">Total balance</p>
          <p className="total-amount">{money(total)}</p>
          <p className="light-muted">Across {accounts.length} {accounts.length === 1 ? 'account' : 'accounts'}</p>
        </div>
        <button className="btn btn-light btn-sm" onClick={() => setHidden((h) => !h)} aria-pressed={hidden}>
          {hidden ? 'Show balance' : 'Hide balance'}
        </button>
      </section>

      <h2 className="section-title">Your accounts</h2>
      <div className="account-grid">
        {accounts.map((a) => (
          <article className="card account-card" key={a.id}>
            <div className="account-top">
              <span className="pill pill-type">{a.type === 'SAVINGS' ? 'Savings' : 'Current'}</span>
              <span className="mono muted">{hidden ? '•••• ••••' : a.accountNumber}</span>
            </div>
            <p className="account-balance">{money(a.balance)}</p>
            <p className="muted small">Available balance · {maskAccount(a.accountNumber)}</p>

            {depositFor === a.id ? (
              <form className="inline-form" onSubmit={deposit}>
                <label className="sr-only" htmlFor={`dep-${a.id}`}>Deposit amount</label>
                <input id={`dep-${a.id}`} className="input" type="number" min="0.01" step="0.01" autoFocus
                       placeholder="Amount (₹)" value={depositAmount} onChange={(e) => setDepositAmount(e.target.value)} />
                <button className="btn btn-primary btn-sm" disabled={busy}>Add</button>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => setDepositFor(null)}>Cancel</button>
              </form>
            ) : (
              <div className="account-actions">
                <button className="btn btn-outline btn-sm" onClick={() => { setDepositFor(a.id); setDepositAmount(''); }}>
                  Deposit cash
                </button>
                <Link className="btn btn-outline btn-sm" to={`/transactions?account=${a.id}`}>Statement</Link>
              </div>
            )}
          </article>
        ))}

        <article className="card account-card new-account">
          <p className="account-title">Open another account</p>
          <p className="muted small">Up to 5 accounts per customer.</p>
          <div className="inline-form">
            <label className="sr-only" htmlFor="new-type">Account type</label>
            <select id="new-type" className="input" value={newType} onChange={(e) => setNewType(e.target.value)}>
              <option value="SAVINGS">Savings</option>
              <option value="CURRENT">Current</option>
            </select>
            <button className="btn btn-primary btn-sm" onClick={openAccount} disabled={busy}>Open</button>
          </div>
        </article>
      </div>

      <div className="page-head section-gap">
        <h2 className="section-title flush">Recent transactions</h2>
        <Link to="/transactions" className="link">View all</Link>
      </div>
      <div className="card">
        <TransactionList items={recent} showBalance={false} />
      </div>
    </div>
  );
}
