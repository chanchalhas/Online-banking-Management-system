import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api, { errorMessage } from '../api/client';
import { accountLabel } from '../utils';
import Alert from '../components/Alert';
import TransactionList from '../components/TransactionList';

export default function Transactions() {
  const [params, setParams] = useSearchParams();
  const accountId = params.get('account') || '';

  const [accounts, setAccounts] = useState([]);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/accounts').then((r) => setAccounts(r.data)).catch((e) => setError(errorMessage(e)));
  }, []);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .get('/transactions', { params: { accountId: accountId || undefined, limit: 100 } })
      .then((r) => {
        if (!cancelled) {
          setItems(r.data);
          setError('');
        }
      })
      .catch((e) => !cancelled && setError(errorMessage(e)))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [accountId]);

  const change = (e) => {
    const value = e.target.value;
    setParams(value ? { account: value } : {});
  };

  return (
    <div className="container page">
      <div className="page-head">
        <h1>Transactions</h1>
        <div className="filter">
          <label htmlFor="account-filter" className="sr-only">Account</label>
          <select id="account-filter" className="input" value={accountId} onChange={change}>
            <option value="">All accounts</option>
            {accounts.map((a) => (
              <option key={a.id} value={a.id}>{accountLabel(a)}</option>
            ))}
          </select>
        </div>
      </div>

      <Alert>{error}</Alert>
      <div className="card">
        {loading ? <p className="muted empty">Loading…</p> : <TransactionList items={items} showBalance={Boolean(accountId)} />}
      </div>
      {!accountId && !loading && items.length > 0 && (
        <p className="muted small note">Choose a single account to see the running balance after each transaction.</p>
      )}
    </div>
  );
}
