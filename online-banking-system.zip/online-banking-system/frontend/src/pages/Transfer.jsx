import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errorMessage } from '../api/client';
import { accountLabel, formatDate, formatMoney } from '../utils';
import Alert from '../components/Alert';

const MAX_TRANSFER = 100000; // keep in step with app.bank.max-transfer on the server

export default function Transfer() {
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [step, setStep] = useState('form'); // form -> review -> done
  const [form, setForm] = useState({ fromAccountId: '', toAccountNumber: '', amount: '', description: '' });
  const [beneficiary, setBeneficiary] = useState(null); // { holderName } once the number is confirmed
  const [lookupState, setLookupState] = useState('idle'); // idle | checking | found | missing
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [receipt, setReceipt] = useState(null);

  useEffect(() => {
    api.get('/accounts')
      .then((r) => {
        setAccounts(r.data);
        if (r.data.length > 0) setForm((f) => ({ ...f, fromAccountId: String(r.data[0].id) }));
      })
      .catch((e) => setError(errorMessage(e)))
      .finally(() => setLoading(false));
  }, []);

  // Look up the account holder's name as soon as a full account number is typed.
  useEffect(() => {
    const number = form.toAccountNumber.trim();
    setBeneficiary(null);
    if (!/^\d{10,12}$/.test(number)) {
      setLookupState('idle');
      return undefined;
    }
    let cancelled = false;
    setLookupState('checking');
    const timer = setTimeout(() => {
      api.get(`/accounts/lookup/${number}`)
        .then((r) => {
          if (cancelled) return;
          setBeneficiary(r.data);
          setLookupState('found');
        })
        .catch(() => !cancelled && setLookupState('missing'));
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [form.toAccountNumber]);

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  const source = accounts.find((a) => String(a.id) === form.fromAccountId);

  /** Client-side checks. The server repeats all of them, these only give faster feedback. */
  const validate = () => {
    const amount = Number(form.amount);
    if (!source) return 'Choose the account to send from';
    if (!/^\d{10,12}$/.test(form.toAccountNumber.trim())) return 'Enter the 10 to 12 digit beneficiary account number';
    if (form.toAccountNumber.trim() === source.accountNumber) return 'You cannot send money to the same account';
    if (lookupState === 'missing') return 'No account found with that number';
    if (lookupState !== 'found') return 'Wait while we check the beneficiary account';
    if (!(amount > 0)) return 'Enter an amount greater than zero';
    if (!/^\d+(\.\d{1,2})?$/.test(form.amount.trim())) return 'Amount can have at most 2 decimal places';
    if (amount > MAX_TRANSFER) return `A single transfer cannot be more than ${formatMoney(MAX_TRANSFER)}`;
    if (amount > Number(source.balance)) return 'Insufficient balance in the selected account';
    return '';
  };

  const review = (e) => {
    e.preventDefault();
    const problem = validate();
    setError(problem);
    if (!problem) setStep('review');
  };

  const confirm = async () => {
    setError('');
    setSubmitting(true);
    try {
      const { data } = await api.post('/transfers', {
        fromAccountId: Number(form.fromAccountId),
        toAccountNumber: form.toAccountNumber.trim(),
        amount: Number(form.amount),
        description: form.description.trim() || undefined,
      });
      setReceipt(data);
      setStep('done');
    } catch (err) {
      setError(errorMessage(err));
      setStep('form');
    } finally {
      setSubmitting(false);
    }
  };

  const reset = () => {
    setForm((f) => ({ ...f, toAccountNumber: '', amount: '', description: '' }));
    setReceipt(null);
    setError('');
    setStep('form');
  };

  if (loading) return <div className="container page"><p className="muted">Loading…</p></div>;

  if (step === 'done' && receipt) {
    return (
      <div className="container page narrow">
        <div className="card receipt">
          <div className="tick" aria-hidden="true">✓</div>
          <h1>Transfer successful</h1>
          <p className="receipt-amount">{formatMoney(receipt.amount)}</p>
          <dl className="details">
            <div><dt>To</dt><dd>{receipt.toHolderName} · {receipt.toAccountNumber}</dd></div>
            <div><dt>From account</dt><dd>{receipt.fromAccountNumber}</dd></div>
            <div><dt>Reference</dt><dd className="mono">{receipt.reference}</dd></div>
            <div><dt>Date</dt><dd>{formatDate(receipt.createdAt)}</dd></div>
            <div><dt>Balance now</dt><dd>{formatMoney(receipt.fromBalanceAfter)}</dd></div>
          </dl>
          <div className="actions">
            <button className="btn btn-primary" onClick={reset}>Send another</button>
            <Link to="/" className="btn btn-outline">Back to dashboard</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container page narrow">
      <h1>Send money</h1>
      <Alert>{error}</Alert>

      {step === 'review' ? (
        <div className="card form">
          <h2>Review and confirm</h2>
          <dl className="details">
            <div><dt>From</dt><dd>{accountLabel(source)}</dd></div>
            <div><dt>To</dt><dd>{beneficiary?.holderName} · {form.toAccountNumber.trim()}</dd></div>
            <div><dt>Amount</dt><dd><strong>{formatMoney(form.amount)}</strong></dd></div>
            {form.description.trim() && <div><dt>Note</dt><dd>{form.description.trim()}</dd></div>}
          </dl>
          <p className="muted small">Transfers cannot be reversed. Check the name above matches the person you mean to pay.</p>
          <div className="actions">
            <button className="btn btn-primary" onClick={confirm} disabled={submitting}>
              {submitting ? 'Sending…' : `Confirm and send ${formatMoney(form.amount)}`}
            </button>
            <button className="btn btn-outline" onClick={() => setStep('form')} disabled={submitting}>Edit</button>
          </div>
        </div>
      ) : (
        <form className="card form" onSubmit={review}>
          <label htmlFor="from">
            From account
            <select id="from" className="input" value={form.fromAccountId} onChange={update('fromAccountId')} required>
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>{accountLabel(a)} — {formatMoney(a.balance)}</option>
              ))}
            </select>
          </label>

          <label htmlFor="to">
            Beneficiary account number
            <input id="to" className="input mono" inputMode="numeric" maxLength={12} placeholder="e.g. 1000000003"
                   value={form.toAccountNumber} onChange={update('toAccountNumber')} required />
            <span className={`hint hint-${lookupState}`} aria-live="polite">
              {lookupState === 'checking' && 'Checking…'}
              {lookupState === 'found' && `Account holder: ${beneficiary.holderName}`}
              {lookupState === 'missing' && 'No account found with that number'}
              {lookupState === 'idle' && 'Ask the receiver for their account number'}
            </span>
          </label>

          <label htmlFor="amount">
            Amount (₹)
            <input id="amount" className="input" type="number" min="0.01" step="0.01" placeholder="0.00"
                   value={form.amount} onChange={update('amount')} required />
            {source && <span className="hint">Available: {formatMoney(source.balance)}</span>}
          </label>

          <label htmlFor="note">
            Note <span className="muted">(optional)</span>
            <input id="note" className="input" maxLength={140} placeholder="Rent, dinner, gift…"
                   value={form.description} onChange={update('description')} />
          </label>

          <button className="btn btn-primary btn-block">Review transfer</button>
        </form>
      )}
    </div>
  );
}
