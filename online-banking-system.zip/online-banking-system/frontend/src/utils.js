export const formatMoney = (value) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2 }).format(value ?? 0);

export const formatDate = (iso) =>
  new Date(iso).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });

/** 1000000001 -> •••• 0001 */
export const maskAccount = (number = '') => `•••• ${number.slice(-4)}`;

export const accountLabel = (account) =>
  `${account.type === 'SAVINGS' ? 'Savings' : 'Current'} ${maskAccount(account.accountNumber)}`;
