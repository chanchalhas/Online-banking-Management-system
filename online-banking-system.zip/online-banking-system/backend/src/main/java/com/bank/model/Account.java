package com.bank.model;

import java.math.BigDecimal;
import java.time.Instant;

public record Account(long id, long userId, String accountNumber, AccountType type,
                      BigDecimal balance, Instant createdAt) {
}
