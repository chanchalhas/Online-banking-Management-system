package com.bank.security;

/** The logged-in user, as read from the JWT. Injected into controllers with @AuthenticationPrincipal. */
public record AuthUser(long id, String email) {
}
