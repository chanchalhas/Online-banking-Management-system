package com.bank.dto;

import com.bank.model.Account;
import com.bank.model.AccountType;
import com.bank.model.User;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.Instant;

/** All request / response shapes of the API in one place. */
public final class Dtos {

    private Dtos() {}

    // ---------- Auth ----------

    public record RegisterRequest(
            @NotBlank @Size(max = 100) String fullName,
            @NotBlank @Email @Size(max = 150) String email,
            @NotBlank @Size(min = 8, max = 100) String password,
            @Pattern(regexp = "^[0-9+\\- ]{7,20}$", message = "Enter a valid phone number") String phone) {}

    public record LoginRequest(@NotBlank @Email String email, @NotBlank String password) {}

    public record UserResponse(long id, String fullName, String email, String phone) {
        public static UserResponse from(User u) {
            return new UserResponse(u.id(), u.fullName(), u.email(), u.phone());
        }
    }

    public record AuthResponse(String token, UserResponse user) {}

    // ---------- Accounts ----------

    public record OpenAccountRequest(@NotNull AccountType type) {}

    public record AccountResponse(long id, String accountNumber, AccountType type, BigDecimal balance, Instant createdAt) {
        public static AccountResponse from(Account a) {
            return new AccountResponse(a.id(), a.accountNumber(), a.type(), a.balance(), a.createdAt());
        }
    }

    public record DepositRequest(
            @NotNull @DecimalMin(value = "0.01", message = "Amount must be at least 0.01")
            @Digits(integer = 10, fraction = 2, message = "Amount can have at most 2 decimal places") BigDecimal amount) {}

    public record LookupResponse(String accountNumber, String holderName) {}

    // ---------- Transfers & history ----------

    public record TransferRequest(
            @NotNull Long fromAccountId,
            @NotBlank @Pattern(regexp = "\\d{10,12}", message = "Account number must be 10 to 12 digits") String toAccountNumber,
            @NotNull @DecimalMin(value = "0.01", message = "Amount must be at least 0.01")
            @Digits(integer = 10, fraction = 2, message = "Amount can have at most 2 decimal places") BigDecimal amount,
            @Size(max = 140) String description) {}

    public record TransferResponse(String reference, BigDecimal amount, String fromAccountNumber,
                                   String toAccountNumber, String toHolderName,
                                   BigDecimal fromBalanceAfter, Instant createdAt) {}

    /** direction is DEBIT, CREDIT or INTERNAL (between two of the user's own accounts). */
    public record TransactionView(long id, String reference, String type, String direction, BigDecimal amount,
                                  BigDecimal balanceAfter, String description,
                                  String counterpartyName, String counterpartyAccount, Instant createdAt) {}

    public record ErrorResponse(int status, String message) {}
}
