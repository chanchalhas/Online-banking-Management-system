package com.bank.config;

import com.bank.dto.Dtos.TransferRequest;
import com.bank.model.AccountType;
import com.bank.repository.AccountRepository;
import com.bank.repository.TransactionRepository;
import com.bank.repository.UserRepository;
import com.bank.service.TransferService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.UUID;

/** On the very first run, creates two demo customers so transfers can be tried straight away. */
@Component
public class DataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    private final UserRepository users;
    private final AccountRepository accounts;
    private final TransactionRepository transactions;
    private final TransferService transfers;
    private final PasswordEncoder encoder;

    public DataSeeder(UserRepository users, AccountRepository accounts, TransactionRepository transactions,
                      TransferService transfers, PasswordEncoder encoder) {
        this.users = users;
        this.accounts = accounts;
        this.transactions = transactions;
        this.transfers = transfers;
        this.encoder = encoder;
    }

    @Override
    public void run(String... args) {
        if (users.count() > 0) {
            return;
        }

        long aarav = users.insert("Aarav Sharma", "demo@bank.com", encoder.encode("demo1234"), "9876543210");
        long priya = users.insert("Priya Nair", "friend@bank.com", encoder.encode("friend1234"), "9123456780");

        long aaravSavings = openWith(aarav, "1000000001", AccountType.SAVINGS, "25000");
        openWith(aarav, "1000000002", AccountType.CURRENT, "5000");
        long priyaSavings = openWith(priya, "1000000003", AccountType.SAVINGS, "12000");

        // A little history so the statement page is not empty
        transfers.transfer(aarav, new TransferRequest(aaravSavings, "1000000003", new BigDecimal("1500.00"), "Dinner split"));
        transfers.transfer(priya, new TransferRequest(priyaSavings, "1000000001", new BigDecimal("800.00"), "Cab fare"));

        log.info("Created demo customers: demo@bank.com / demo1234 and friend@bank.com / friend1234");
    }

    private long openWith(long userId, String accountNumber, AccountType type, String balance) {
        BigDecimal amount = new BigDecimal(balance);
        long id = accounts.insert(userId, accountNumber, type, amount);
        String reference = "TXN" + UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase();
        transactions.insert(reference, "DEPOSIT", null, id, amount, null, amount, "Opening balance");
        return id;
    }
}
