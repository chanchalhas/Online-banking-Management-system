package com.bank.service;

import com.bank.dto.Dtos.*;
import com.bank.exception.ApiException;
import com.bank.model.Account;
import com.bank.model.AccountType;
import com.bank.repository.AccountRepository;
import com.bank.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
public class AccountService {

    private final AccountRepository accounts;
    private final TransactionRepository transactions;
    private final int maxAccounts;
    private final BigDecimal maxDeposit;

    public AccountService(AccountRepository accounts, TransactionRepository transactions,
                          @Value("${app.bank.max-accounts}") int maxAccounts,
                          @Value("${app.bank.max-deposit}") BigDecimal maxDeposit) {
        this.accounts = accounts;
        this.transactions = transactions;
        this.maxAccounts = maxAccounts;
        this.maxDeposit = maxDeposit;
    }

    public List<AccountResponse> listMine(long userId) {
        return accounts.findByUser(userId).stream().map(AccountResponse::from).toList();
    }

    /** Checking a balance: only the owner can read an account. */
    public AccountResponse getMine(long userId, long accountId) {
        return AccountResponse.from(accounts.findOwned(accountId, userId)
                .orElseThrow(() -> ApiException.notFound("Account not found")));
    }

    @Transactional
    public AccountResponse open(long userId, AccountType type) {
        if (accounts.countByUser(userId) >= maxAccounts) {
            throw ApiException.badRequest("You can have at most " + maxAccounts + " accounts");
        }
        long id = accounts.insert(userId, accounts.generateAccountNumber(), type, BigDecimal.ZERO);
        return AccountResponse.from(accounts.findOwned(id, userId).orElseThrow());
    }

    /** Demo cash deposit so a new account has money to play with. */
    @Transactional
    public AccountResponse deposit(long userId, long accountId, BigDecimal amount) {
        if (amount.compareTo(maxDeposit) > 0) {
            throw ApiException.badRequest("A single deposit cannot be more than " + maxDeposit.toPlainString());
        }
        Account account = accounts.lockOwned(accountId, userId)
                .orElseThrow(() -> ApiException.notFound("Account not found"));
        accounts.credit(account.id(), amount);
        BigDecimal after = account.balance().add(amount);
        transactions.insert(newReference(), "DEPOSIT", null, account.id(), amount, null, after, "Cash deposit");
        return AccountResponse.from(accounts.findOwned(accountId, userId).orElseThrow());
    }

    /** Shows the beneficiary's name (first name + last initial) so the sender can confirm it before paying. */
    public LookupResponse lookup(String accountNumber) {
        String name = accounts.findHolderName(accountNumber)
                .orElseThrow(() -> ApiException.notFound("No account found with that number"));
        return new LookupResponse(accountNumber, shortName(name));
    }

    static String newReference() {
        return "TXN" + UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase();
    }

    static String shortName(String fullName) {
        String[] parts = fullName.trim().split("\\s+");
        if (parts.length == 1) {
            return parts[0];
        }
        return parts[0] + " " + parts[parts.length - 1].charAt(0) + ".";
    }
}
