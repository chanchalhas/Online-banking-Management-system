package com.bank.controller;

import com.bank.dto.Dtos.*;
import com.bank.security.AuthUser;
import com.bank.service.AccountService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    private final AccountService accounts;

    public AccountController(AccountService accounts) {
        this.accounts = accounts;
    }

    @GetMapping
    public List<AccountResponse> mine(@AuthenticationPrincipal AuthUser user) {
        return accounts.listMine(user.id());
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public AccountResponse open(@AuthenticationPrincipal AuthUser user, @Valid @RequestBody OpenAccountRequest req) {
        return accounts.open(user.id(), req.type());
    }

    /** Account details including the current balance. */
    @GetMapping("/{id}")
    public AccountResponse one(@AuthenticationPrincipal AuthUser user, @PathVariable long id) {
        return accounts.getMine(user.id(), id);
    }

    @PostMapping("/{id}/deposit")
    public AccountResponse deposit(@AuthenticationPrincipal AuthUser user, @PathVariable long id,
                                   @Valid @RequestBody DepositRequest req) {
        return accounts.deposit(user.id(), id, req.amount());
    }

    /** Looks up the name behind an account number before sending money. */
    @GetMapping("/lookup/{accountNumber}")
    public LookupResponse lookup(@PathVariable String accountNumber) {
        return accounts.lookup(accountNumber);
    }
}
