package com.bank.service;

import com.bank.dto.Dtos.*;
import com.bank.exception.ApiException;
import com.bank.model.AccountType;
import com.bank.model.User;
import com.bank.repository.AccountRepository;
import com.bank.repository.UserRepository;
import com.bank.security.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class AuthService {

    private final UserRepository users;
    private final AccountRepository accounts;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    public AuthService(UserRepository users, AccountRepository accounts, PasswordEncoder encoder, JwtService jwt) {
        this.users = users;
        this.accounts = accounts;
        this.encoder = encoder;
        this.jwt = jwt;
    }

    /** Creates the user and their first (savings) account in one database transaction. */
    @Transactional
    public AuthResponse register(RegisterRequest req) {
        String email = req.email().trim().toLowerCase();
        if (users.existsByEmail(email)) {
            throw new ApiException(HttpStatus.CONFLICT, "An account with this email already exists");
        }
        String phone = req.phone() == null || req.phone().isBlank() ? null : req.phone().trim();
        long userId = users.insert(req.fullName().trim(), email, encoder.encode(req.password()), phone);
        accounts.insert(userId, accounts.generateAccountNumber(), AccountType.SAVINGS, BigDecimal.ZERO);
        return toResponse(users.findById(userId).orElseThrow());
    }

    public AuthResponse login(LoginRequest req) {
        // Same error for "no such user" and "wrong password" so emails cannot be probed.
        User user = users.findByEmail(req.email().trim().toLowerCase())
                .orElseThrow(() -> new BadCredentialsException("bad credentials"));
        if (!encoder.matches(req.password(), user.passwordHash())) {
            throw new BadCredentialsException("bad credentials");
        }
        return toResponse(user);
    }

    public UserResponse me(long userId) {
        return UserResponse.from(users.findById(userId)
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "User no longer exists")));
    }

    private AuthResponse toResponse(User user) {
        return new AuthResponse(jwt.generateToken(user.id(), user.email()), UserResponse.from(user));
    }
}
