package com.bank.model;

import java.math.BigDecimal;
import java.time.Instant;

/** One row of the transactions table joined with both accounts' numbers and owners. */
public record TxnRow(long id, String reference, String type,
                     Long fromAccountId, Long toAccountId,
                     String fromNumber, String toNumber,
                     String fromName, String toName,
                     boolean fromMine, boolean toMine,
                     BigDecimal amount, BigDecimal fromBalanceAfter, BigDecimal toBalanceAfter,
                     String description, Instant createdAt) {
}
