package com.bank.service;

import com.bank.dto.Dtos.*;
import com.bank.exception.ApiException;
import com.bank.model.Account;
import com.bank.model.TxnRow;
import com.bank.repository.AccountRepository;
import com.bank.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class TransferService {

    private final AccountRepository accounts;
    private final TransactionRepository transactions;
    private final BigDecimal maxTransfer;

    public TransferService(AccountRepository accounts, TransactionRepository transactions,
                           @Value("${app.bank.max-transfer}") BigDecimal maxTransfer) {
        this.accounts = accounts;
        this.transactions = transactions;
        this.maxTransfer = maxTransfer;
    }

    /**
     * Moves money from one of the user's accounts to any other account.
     * Everything runs in one database transaction: either both balances change and the
     * transaction row is written, or nothing changes at all.
     */
    @Transactional
    public TransferResponse transfer(long userId, TransferRequest req) {
        BigDecimal amount = req.amount();

        // 1. Validation that needs no database access
        if (amount.compareTo(maxTransfer) > 0) {
            throw ApiException.badRequest("A single transfer cannot be more than " + maxTransfer.toPlainString());
        }

        // 2. The source must belong to the logged-in user; the destination must exist
        Account from = accounts.findOwned(req.fromAccountId(), userId)
                .orElseThrow(() -> ApiException.notFound("Source account not found"));
        Account to = accounts.findByNumber(req.toAccountNumber())
                .orElseThrow(() -> ApiException.notFound("Beneficiary account not found"));
        if (from.id() == to.id()) {
            throw ApiException.badRequest("Source and destination accounts must be different");
        }

        // 3. Lock both rows (in id order) and re-read the balances, so nobody can change them mid-transfer
        List<Account> locked = accounts.lockBoth(from.id(), to.id());
        Account lockedFrom = locked.stream().filter(a -> a.id() == from.id()).findFirst().orElseThrow();
        Account lockedTo = locked.stream().filter(a -> a.id() == to.id()).findFirst().orElseThrow();

        // 4. Enough money?
        if (lockedFrom.balance().compareTo(amount) < 0) {
            throw ApiException.badRequest("Insufficient balance");
        }

        // 5. Move the money
        if (!accounts.debit(lockedFrom.id(), amount)) {
            throw ApiException.badRequest("Insufficient balance");
        }
        accounts.credit(lockedTo.id(), amount);

        BigDecimal fromAfter = lockedFrom.balance().subtract(amount);
        BigDecimal toAfter = lockedTo.balance().add(amount);
        String reference = AccountService.newReference();
        String description = req.description() == null || req.description().isBlank() ? "Fund transfer" : req.description().trim();

        // 6. Record it
        transactions.insert(reference, "TRANSFER", lockedFrom.id(), lockedTo.id(), amount, fromAfter, toAfter, description);

        String holder = accounts.findHolderName(lockedTo.accountNumber()).map(AccountService::shortName).orElse("");
        return new TransferResponse(reference, amount, lockedFrom.accountNumber(), lockedTo.accountNumber(),
                holder, fromAfter, java.time.Instant.now());
    }

    /** History for the user's accounts, newest first, optionally limited to one account. */
    public List<TransactionView> history(long userId, Long accountId, int limit) {
        if (accountId != null && accounts.findOwned(accountId, userId).isEmpty()) {
            throw ApiException.notFound("Account not found");
        }
        int safeLimit = Math.max(1, Math.min(limit, 200));
        return transactions.findForUser(userId, accountId, safeLimit).stream()
                .map(row -> toView(row, accountId))
                .toList();
    }

    private static TransactionView toView(TxnRow r, Long accountId) {
        boolean debit;
        boolean credit;
        if (accountId != null) {
            debit = accountId.equals(r.fromAccountId());
            credit = accountId.equals(r.toAccountId());
        } else {
            debit = r.fromMine();
            credit = r.toMine();
        }
        String direction = debit && credit ? "INTERNAL" : debit ? "DEBIT" : "CREDIT";
        BigDecimal balanceAfter = debit ? r.fromBalanceAfter() : r.toBalanceAfter();

        String counterpartyName;
        String counterpartyAccount;
        if (direction.equals("DEBIT")) {
            counterpartyName = r.toName();
            counterpartyAccount = r.toNumber();
        } else if (direction.equals("CREDIT")) {
            counterpartyName = r.fromName() == null ? "Cash deposit" : r.fromName();
            counterpartyAccount = r.fromNumber();
        } else {
            counterpartyName = "Your own accounts";
            counterpartyAccount = r.toNumber();
        }
        return new TransactionView(r.id(), r.reference(), r.type(), direction, r.amount(), balanceAfter,
                r.description(), counterpartyName, counterpartyAccount, r.createdAt());
    }
}
