package com.bank.controller;

import com.bank.dto.Dtos.*;
import com.bank.security.AuthUser;
import com.bank.service.TransferService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class TransferController {

    private final TransferService transfers;

    public TransferController(TransferService transfers) {
        this.transfers = transfers;
    }

    @PostMapping("/transfers")
    @ResponseStatus(HttpStatus.CREATED)
    public TransferResponse transfer(@AuthenticationPrincipal AuthUser user, @Valid @RequestBody TransferRequest req) {
        return transfers.transfer(user.id(), req);
    }

    @GetMapping("/transactions")
    public List<TransactionView> history(@AuthenticationPrincipal AuthUser user,
                                         @RequestParam(required = false) Long accountId,
                                         @RequestParam(defaultValue = "50") int limit) {
        return transfers.history(user.id(), accountId, limit);
    }
}
