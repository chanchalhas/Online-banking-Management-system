package com.bank.repository;

import com.bank.model.Account;
import com.bank.model.AccountType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

/** All SQL for the accounts table. */
@Repository
public class AccountRepository {

    private static final String COLUMNS = "id, user_id, account_number, account_type, balance, created_at";

    private static final RowMapper<Account> MAPPER = (rs, i) -> new Account(
            rs.getLong("id"),
            rs.getLong("user_id"),
            rs.getString("account_number"),
            AccountType.valueOf(rs.getString("account_type")),
            rs.getBigDecimal("balance"),
            rs.getObject("created_at", LocalDateTime.class).toInstant(ZoneOffset.UTC));

    private final JdbcTemplate jdbc;
    private final SecureRandom random = new SecureRandom();

    public AccountRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // ---------- Read ----------

    public List<Account> findByUser(long userId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM accounts WHERE user_id = ? ORDER BY id", MAPPER, userId);
    }

    public int countByUser(long userId) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM accounts WHERE user_id = ?", Integer.class, userId);
        return n == null ? 0 : n;
    }

    public Optional<Account> findOwned(long accountId, long userId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM accounts WHERE id = ? AND user_id = ?",
                MAPPER, accountId, userId).stream().findFirst();
    }

    public Optional<Account> findByNumber(String accountNumber) {
        return jdbc.query("SELECT " + COLUMNS + " FROM accounts WHERE account_number = ?",
                MAPPER, accountNumber).stream().findFirst();
    }

    public boolean existsByNumber(String accountNumber) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM accounts WHERE account_number = ?",
                Integer.class, accountNumber);
        return n != null && n > 0;
    }

    /** Name of the person who owns the account (used to confirm the beneficiary before a transfer). */
    public Optional<String> findHolderName(String accountNumber) {
        return jdbc.queryForList(
                "SELECT u.full_name FROM accounts a JOIN users u ON u.id = a.user_id WHERE a.account_number = ?",
                String.class, accountNumber).stream().findFirst();
    }

    // ---------- Row locks (must be called inside a transaction) ----------

    /** Locks one account row for the rest of the transaction, only if it belongs to the user. */
    public Optional<Account> lockOwned(long accountId, long userId) {
        return jdbc.query("SELECT " + COLUMNS + " FROM accounts WHERE id = ? AND user_id = ? FOR UPDATE",
                MAPPER, accountId, userId).stream().findFirst();
    }

    /**
     * Locks two account rows. They are always locked in id order, so two transfers going in
     * opposite directions at the same time can never deadlock each other.
     */
    public List<Account> lockBoth(long idA, long idB) {
        return jdbc.query("SELECT " + COLUMNS + " FROM accounts WHERE id IN (?, ?) ORDER BY id FOR UPDATE",
                MAPPER, idA, idB);
    }

    // ---------- Write ----------

    public long insert(long userId, String accountNumber, AccountType type, BigDecimal openingBalance) {
        KeyHolder keys = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO accounts (user_id, account_number, account_type, balance, created_at) VALUES (?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1, userId);
            ps.setString(2, accountNumber);
            ps.setString(3, type.name());
            ps.setBigDecimal(4, openingBalance);
            ps.setObject(5, LocalDateTime.now(ZoneOffset.UTC));
            return ps;
        }, keys);
        return keys.getKey().longValue();
    }

    /** Takes money out only if enough is there. Returns false when the balance is too low. */
    public boolean debit(long accountId, BigDecimal amount) {
        return jdbc.update("UPDATE accounts SET balance = balance - ? WHERE id = ? AND balance >= ?",
                amount, accountId, amount) == 1;
    }

    public void credit(long accountId, BigDecimal amount) {
        jdbc.update("UPDATE accounts SET balance = balance + ? WHERE id = ?", amount, accountId);
    }

    /** Creates a random 10-digit account number that is not used yet (starts with 10). */
    public String generateAccountNumber() {
        String number;
        do {
            number = "10" + String.format("%08d", random.nextInt(100_000_000));
        } while (existsByNumber(number));
        return number;
    }
}
