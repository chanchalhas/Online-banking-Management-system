package com.bank.repository;

import com.bank.model.TxnRow;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

/** All SQL for the transactions table. */
@Repository
public class TransactionRepository {

    private static final RowMapper<TxnRow> MAPPER = (rs, i) -> new TxnRow(
            rs.getLong("id"),
            rs.getString("reference"),
            rs.getString("txn_type"),
            rs.getObject("from_account_id", Long.class),
            rs.getObject("to_account_id", Long.class),
            rs.getString("from_number"),
            rs.getString("to_number"),
            rs.getString("from_name"),
            rs.getString("to_name"),
            rs.getBoolean("from_mine"),
            rs.getBoolean("to_mine"),
            rs.getBigDecimal("amount"),
            rs.getBigDecimal("from_balance_after"),
            rs.getBigDecimal("to_balance_after"),
            rs.getString("description"),
            rs.getObject("created_at", LocalDateTime.class).toInstant(ZoneOffset.UTC));

    private final JdbcTemplate jdbc;

    public TransactionRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void insert(String reference, String type, Long fromAccountId, Long toAccountId, BigDecimal amount,
                       BigDecimal fromBalanceAfter, BigDecimal toBalanceAfter, String description) {
        jdbc.update("""
                INSERT INTO transactions
                  (reference, txn_type, from_account_id, to_account_id, amount,
                   from_balance_after, to_balance_after, description, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                reference, type, fromAccountId, toAccountId, amount,
                fromBalanceAfter, toBalanceAfter, description, LocalDateTime.now(ZoneOffset.UTC));
    }

    /**
     * Newest-first history of every transaction that touches one of the user's accounts.
     * When accountId is given, only that account's transactions are returned.
     */
    public List<TxnRow> findForUser(long userId, Long accountId, int limit) {
        StringBuilder sql = new StringBuilder("""
                SELECT t.id, t.reference, t.txn_type, t.from_account_id, t.to_account_id,
                       fa.account_number AS from_number, ta.account_number AS to_number,
                       fu.full_name AS from_name, tu.full_name AS to_name,
                       (fa.user_id = ?) AS from_mine, (ta.user_id = ?) AS to_mine,
                       t.amount, t.from_balance_after, t.to_balance_after, t.description, t.created_at
                FROM transactions t
                LEFT JOIN accounts fa ON fa.id = t.from_account_id
                LEFT JOIN accounts ta ON ta.id = t.to_account_id
                LEFT JOIN users fu ON fu.id = fa.user_id
                LEFT JOIN users tu ON tu.id = ta.user_id
                WHERE (fa.user_id = ? OR ta.user_id = ?)
                """);
        List<Object> args = new ArrayList<>(List.of(userId, userId, userId, userId));
        if (accountId != null) {
            sql.append(" AND (t.from_account_id = ? OR t.to_account_id = ?)");
            args.add(accountId);
            args.add(accountId);
        }
        sql.append(" ORDER BY t.created_at DESC, t.id DESC LIMIT ?");
        args.add(limit);
        return jdbc.query(sql.toString(), MAPPER, args.toArray());
    }
}
